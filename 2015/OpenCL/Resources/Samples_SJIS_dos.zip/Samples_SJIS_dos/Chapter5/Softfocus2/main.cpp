// List5.20

/*
 *  main.cpp (rev1.1, 28.Nov.2010)
 *  Copyright 2010 Takashi Okuzono. All rights reserved.
 */

#include <stdio.h>
#include <string.h>
#include "Bitmap.h"
#include "MyError.h"
#include "ClHelper.h"

static const char* INFILE  = "../../input.bmp";  // ����bitmap�t�@�C��
static const char* OUTFILE = "../../output.bmp"; // �o��bitmap�t�@�C��

/*-------------------------------------------------------------------------
 * �\�t�g�t�H�[�J�X���� (OpenCL���g��������)
 */
static void
softfocusWithOpenCL(unsigned char* dataR,
                    unsigned char* dataG,
                    unsigned char* dataB,
                    const unsigned int width,
                    const unsigned int height)
{
    ClHelper clHelper;
    clHelper.preloadProgram("../../calc.cl");  // �J�[�l���v���O�����̓ǂݍ���

    unsigned int datasize = width * height;
    unsigned char* origR = new unsigned char[datasize];
    unsigned char* origG = new unsigned char[datasize];
    unsigned char* origB = new unsigned char[datasize];

    // �s�N�Z���f�[�^�̕ۑ�
    memcpy(origR, dataR, datasize);
    memcpy(origG, dataG, datasize);
    memcpy(origB, dataB, datasize);        

    cl_context       context = clHelper.getContext();      // �R���e�L�X�g�̎擾
    cl_command_queue queue   = clHelper.getCommandQueue(); // �R�}���h�L���[�̎擾
    cl_program       program = clHelper.getProgram();      // �v���O�����̎擾
    if (program == (cl_program)0) {
        throw MyError("program bug, program object is not loaded", __FUNCTION__);
    }

    cl_int status;

    // �J�[�l���̍쐬
    cl_kernel kernel;
    kernel = clCreateKernel(program, "processPixel", &status);
    if (kernel == (cl_kernel)0) {
        printf("clCreateKernel failed\n");
        ClHelper::printError(status);
        throw MyError("failed to create kernel", __FUNCTION__);
    }

    // �������I�u�W�F�N�g�̍쐬 �i����R�j
    cl_mem inR = clCreateBuffer(context,
                                CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
                                sizeof(cl_uchar) * datasize, origR, &status);
    if (status != CL_SUCCESS) {
        ClHelper::printError(status);
        throw MyError("failed to create memory object", __FUNCTION__);
    }

    // �������I�u�W�F�N�g�̍쐬 �i����G�j
    cl_mem inG = clCreateBuffer(context,
                                CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
                                sizeof(cl_uchar) * datasize, origG, &status);
    if (status != CL_SUCCESS) {
        ClHelper::printError(status);
        throw MyError("failed to create memory object", __FUNCTION__);
    }

    // �������I�u�W�F�N�g�̍쐬 �i����B�j
    cl_mem inB = clCreateBuffer(context,
                                CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
                                sizeof(cl_uchar) * datasize, origB, &status);
    if (status != CL_SUCCESS) {
        ClHelper::printError(status);
        throw MyError("failed to create memory object", __FUNCTION__);
    }

    // �������I�u�W�F�N�g�̍쐬 �i�o��R�j
    cl_mem outR = clCreateBuffer(context,
                                 CL_MEM_WRITE_ONLY | CL_MEM_COPY_HOST_PTR,
                                 sizeof(cl_uchar) * datasize, origR, &status);
    if (status != CL_SUCCESS) {
        ClHelper::printError(status);
        throw MyError("failed to create memory object", __FUNCTION__);
    }

    // �������I�u�W�F�N�g�̍쐬 �i�o��G�j
    cl_mem outG = clCreateBuffer(context,
                                 CL_MEM_WRITE_ONLY | CL_MEM_COPY_HOST_PTR,
                                 sizeof(cl_uchar) * datasize, origG, &status);
    if (status != CL_SUCCESS) {
        ClHelper::printError(status);
        throw MyError("failed to create memory object", __FUNCTION__);
    }

    // �������I�u�W�F�N�g�̍쐬 �i�o��B�j
    cl_mem outB = clCreateBuffer(context,
                                 CL_MEM_WRITE_ONLY | CL_MEM_COPY_HOST_PTR,
                                 sizeof(cl_uchar) * datasize, origB, &status);
    if (status != CL_SUCCESS) {
        ClHelper::printError(status);
        throw MyError("failed to create memory object", __FUNCTION__);
    }

    // �J�[�l���֐������̃Z�b�g
    status =  clSetKernelArg(kernel, 0, sizeof(cl_uint), (void *)&width);
    status += clSetKernelArg(kernel, 1, sizeof(inR),  (void *)&inR);
    status += clSetKernelArg(kernel, 2, sizeof(inG),  (void *)&inG);
    status += clSetKernelArg(kernel, 3, sizeof(inB),  (void *)&inB);
    status += clSetKernelArg(kernel, 4, sizeof(outR), (void *)&outR);
    status += clSetKernelArg(kernel, 5, sizeof(outG), (void *)&outG);
    status += clSetKernelArg(kernel, 6, sizeof(outB), (void *)&outB);

    if (status != 0) {
        printf("clSetKernelArg failed\n");
        throw MyError("failed to set kernel arguments.", __FUNCTION__);
    }

    // �J�[�l�����s�̃��N�G�X�g
    cl_uint work_dim = 2; // x, y
    size_t global_work_size[] = {width - 2, height - 2};

    status = clEnqueueNDRangeKernel(queue, kernel, work_dim, NULL,
                                    global_work_size, 0, 0, NULL, NULL);
    if (status != CL_SUCCESS) {
        ClHelper::printError(status);
        throw MyError("clEnqueueNDRangeKernel failed.", __FUNCTION__);
    }

    // �v�Z���ʂ̎擾 (R)
    status = clEnqueueReadBuffer(queue, outR, CL_TRUE, 0,
                                 sizeof(cl_uchar) * datasize, dataR,
                                 0, NULL, NULL);
    if (status != CL_SUCCESS) {
        ClHelper::printError(status);
        throw MyError("clEnqueueReadBuffer failed.", __FUNCTION__);
    }

    // �v�Z���ʂ̎擾 (G)
    status = clEnqueueReadBuffer(queue, outG, CL_TRUE, 0,
                                 sizeof(cl_uchar) * datasize, dataG,
                                 0, NULL, NULL);
    if (status != CL_SUCCESS) {
        ClHelper::printError(status);
        throw MyError("clEnqueueReadBuffer failed.", __FUNCTION__);
    }

    // �v�Z���ʂ̎擾 (B)
    status = clEnqueueReadBuffer(queue, outB, CL_TRUE, 0,
                                 sizeof(cl_uchar) * datasize, dataB,
                                 0, NULL, NULL);
    if (status != CL_SUCCESS) {
        ClHelper::printError(status);
        throw MyError("clEnqueueReadBuffer failed.", __FUNCTION__);
    }

    // ���\�[�X�̉��
    clReleaseMemObject(outB);
    clReleaseMemObject(outG);
    clReleaseMemObject(outR);
    clReleaseMemObject(inB);
    clReleaseMemObject(inG);
    clReleaseMemObject(inR);

    delete [] origB;
    delete [] origG;    
    delete [] origR;
}

/*-------------------------------------------------------------------------
 * �\�t�g�t�H�[�J�X�����������Ȃ��v���O���� (OpenCL���g��������)
 */
int main()
{
    try {
        // �r�b�g�}�b�v�t�@�C���̓ǂݍ���
        Bitmap bm;
        bm.readFile(INFILE);

        // �r�b�g�}�b�v���̎擾
        int width  = bm.getWidth();
        int height = bm.getHeight();    
        unsigned const int absHeight = height > 0 ? height : height * -1;
        unsigned const int datasize = width * absHeight;

        // �s�N�Z���o�b�t�@�̃A���P�[�g
        unsigned char* dataR = new unsigned char[datasize];
        unsigned char* dataG = new unsigned char[datasize];
        unsigned char* dataB = new unsigned char[datasize];    

        // �s�N�Z���f�[�^�̎擾
        bm.getRgbData(dataR, dataG, dataB);    

        // �\�t�g�t�H�[�J�X����
        softfocusWithOpenCL(dataR, dataG, dataB, width, absHeight);

        // ���ʂ̃r�b�g�}�b�v�t�@�C���ւ̏����o��
        Bitmap outBm;
        outBm.create(width, height, dataR, dataG, dataB);
        outBm.writeFile(OUTFILE);

        delete [] dataB;
        delete [] dataG;
        delete [] dataR;
    } catch (MyError err) {
        // �G���[����
        fprintf(stderr, "Error: %s\n", err.cstr());
        return 1;
    }

    return 0;
}
