// List6.8

/*
 *  Stopwatch.cpp (rev1.1, 28.Nov.2010)
 *  Copyright 2010 Takashi Okuzono. All rights reserved.
 */

/*
 * ���ԑ���pStopwatch�N���X�̎����iLinux, MacOS�p�j
 */

#include <sys/time.h>
#include <stdio.h>
#include <string.h>
#include <iostream>

#include "Stopwatch.h"

/*-------------------------------------------------------------------------
 * �R���X�g���N�^
 */
Stopwatch::Stopwatch()
{
    memset(&mStart, 0, sizeof(timeval)); 
    memset(&mStop, 0, sizeof(timeval));
}

/*-------------------------------------------------------------------------
 * �f�X�g���N�^
 */
Stopwatch::~Stopwatch()
{
}

/*-------------------------------------------------------------------------
 * ���Ԍv�����J�n����
 */
void
Stopwatch::start()
{
    if (gettimeofday(&mStart, NULL) != 0) {
        perror("gettimeofday()");
        return;
    }
}

/*-------------------------------------------------------------------------
 * ���Ԍv�����I������
 */
void
Stopwatch::stop()
{
    if (gettimeofday(&mStop, NULL) != 0) {
        perror("gettimeofday()");
        return;
    }
    
    uint64_t diffSec;
    uint64_t diffMicroSec;
    uint64_t startSec      = mStart.tv_sec;
    uint64_t startMicroSec = mStart.tv_usec;
    uint64_t stopSec       = mStop.tv_sec;
    uint64_t stopMicroSec  = mStop.tv_usec;
    
    if (stopMicroSec < startMicroSec) {
        diffSec      = stopSec - startSec - 1;
        diffMicroSec = stopMicroSec + 1000000LL - startMicroSec;
    } else {
        diffSec      = stopSec - startSec;
        diffMicroSec = stopMicroSec - startMicroSec;
    }

    mElapsed = (diffSec * 1000000LL) + diffMicroSec;
}

/*-------------------------------------------------------------------------
 *�@���ʂ�\������
 */
void
Stopwatch::printResult(std::ostream& os) const
{
    os << "total: " << elapseTotalMilliSec() << " (ms)" << std::endl;
    os << "(" << elapseTotalMicroSec() << " (us))" << std::endl;
}

/*-------------------------------------------------------------------------
 * �o�ߎ��Ԃ�ms�P�ʂŕԂ�
 */
uint64_t
Stopwatch::elapseTotalMilliSec() const
{
    return ((mElapsed + 500LL) / 1000LL);
}

/*-------------------------------------------------------------------------
 * �o�ߎ��Ԃ�us�P�ʂŕԂ�
 */
uint64_t
Stopwatch::elapseTotalMicroSec() const
{
    return mElapsed;
}
