// List6.6

/*
 *  Stopwatch.cpp (rev1.1, 28.Nov.2010)
 *  Copyright 2010 Takashi Okuzono. All rights reserved.
 */

/*
 * ���ԑ���pStopwatch�N���X�̎����iMacOS�p�j
 */
#include <iostream>

#include <CoreServices/CoreServices.h>
#include <mach/mach.h>
#include <mach/mach_time.h>

#include "Stopwatch.h"

/*-------------------------------------------------------------------------
 * �R���X�g���N�^
 */
Stopwatch::Stopwatch()
{
    mStart = 0LL;
    mStop = 0LL;    
}

/*-------------------------------------------------------------------------
 * �f�X�g���N�^
 */
Stopwatch::~Stopwatch()
{
}

/*-------------------------------------------------------------------------
 * ���Ԍv�����J�n����
 */
void
Stopwatch::start()
{
    mStart = mach_absolute_time();
}

/*-------------------------------------------------------------------------
 * ���Ԍv�����I������
 */
void
Stopwatch::stop()
{
    mStop = mach_absolute_time();

    uint64_t elapsed = mStop - mStart;
    Nanoseconds nanosec = AbsoluteToNanoseconds(*(AbsoluteTime *) &elapsed);
    mElapsed = *(uint64_t *)&nanosec;
}

/*-------------------------------------------------------------------------
 * ���ʂ�\������
 */
void
Stopwatch::printResult(std::ostream& os) const
{
    os << "total: " << elapseTotalMilliSec() << " (ms)" << std::endl;
    os << "(" << elapseTotalMicroSec() << " (us))" << std::endl;
}

/*-------------------------------------------------------------------------
 * �o�ߎ��Ԃ�ms�P�ʂŕԂ�
 */
uint64_t
Stopwatch::elapseTotalMilliSec() const
{
    return ((mElapsed + 500000LL) / 1000000LL);
}

/*-------------------------------------------------------------------------
 * �o�ߎ��Ԃ�us�P�ʂŕԂ�
 */
uint64_t
Stopwatch::elapseTotalMicroSec() const
{
    return ((mElapsed + 500LL) / 1000LL);
}
