// List3.1

/*
 *  main.cpp (rev1.1, 28.Nov.2010)
 *  Copyright 2010 Takashi Okuozno. All rights reserved.
 */

#include <stdio.h>

#ifdef __APPLE__
#include <OpenCL/opencl.h>
#else
#include <CL/cl.h>
#endif //__APPLE__

static void printPlatformInfo(const cl_platform_id platform_id);

/*---------------------------------------------------------------------------
 *
 */
int
main(int argc, char * const argv[])
{
    // �v���b�g�t�H�[��ID���擾����
    cl_platform_id platforms[10];
    cl_uint num_platforms;
    cl_int status;

    status = clGetPlatformIDs(sizeof(platforms) / sizeof(*platforms),
                              platforms,
                              &num_platforms);
    if (status != CL_SUCCESS) {
        fprintf(stderr, "clGetPlatformIds failed with status %d\n", status);
        return 1;
    }
    
    printf("Number of platform(s) : %d\n", num_platforms);
    for (int i = 0; i < (int)num_platforms; i++) {
        // �v���b�g�t�H�[��ID�ɂ��Ă̏���\������
        printPlatformInfo(platforms[i]);
    }
    
    return 0;
}

/*---------------------------------------------------------------------------
 * �����ŗ^����ꂽ�v���b�g�t�H�[���̏���\������
 * platfomrm_id: ����\������v���b�g�t�H�[����ID
 */
static void
printPlatformInfo(const cl_platform_id platform_id)
{
    char buffer[1024];
    size_t actual_size;
    cl_int status;

    // �v���t�@�C��
    status = clGetPlatformInfo(platform_id, CL_PLATFORM_PROFILE,
                               sizeof(buffer) - 1, buffer, &actual_size);
    printf("Platform profile   : ");
    if (status == CL_SUCCESS) {
        buffer[actual_size] = '\0';
        printf("%s\n", buffer);
    } else {
        printf("Error: clGetPlatformInfo failed with status %d\n", status);
    }

    // �o�[�W����
    status = clGetPlatformInfo(platform_id, CL_PLATFORM_VERSION,
                               sizeof(buffer) - 1, buffer, &actual_size);

    printf("Platform version   : ");
    
    if (status == CL_SUCCESS) {
        buffer[actual_size] = '\0';
        printf("%s\n", buffer);
    } else {
        printf("Error: clGetPlatformInfo failed with status %d\n", status);
    }

    // ���O
    status = clGetPlatformInfo(platform_id, CL_PLATFORM_NAME,
                               sizeof(buffer) - 1, buffer, &actual_size);

    printf("Platform name      : ");

    if (status == CL_SUCCESS) {
        buffer[actual_size] = '\0';
        printf("%s\n", buffer);
    } else {
        printf("Error: clGetPlatformInfo failed with status %d\n", status);
    }

    // �x���_�[
    status = clGetPlatformInfo(platform_id, CL_PLATFORM_VENDOR,
                               sizeof(buffer) - 1, buffer, &actual_size);
    
    printf("Platform vendor    : ");

    if (status == CL_SUCCESS) {
        buffer[actual_size] = '\0';
        printf("%s\n", buffer);
    } else {
        printf("Error: clGetPlatformInfo failed with status %d\n", status);
    }

    // �@�\�g��
    status = clGetPlatformInfo(platform_id, CL_PLATFORM_EXTENSIONS,
                               sizeof(buffer) - 1, buffer, &actual_size);
    
    printf("Platform extensions: ");

    if (status == CL_SUCCESS) {
        buffer[actual_size] = '\0';
        printf("%s\n", buffer);
    } else {
        printf("Error: clGetPlatformInfo failed with status %d\n", status);
    }
}
